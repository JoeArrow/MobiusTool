﻿#region © 2019 JoeWare.
//
// All rights reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical, or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
#endregion

using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using TreePathFinder;

namespace JsonToTreeView.Test
{
    // ----------------------------------------------------
    /// <summary>
    ///     Summary description for ArrowUnitTestXML1
    /// </summary>

    [TestClass]
    public class TreePathFinder_UT
    {
        private const string JSON = "json\\Field 2\\Field 2 Object\\F2ObjF1\\Field 1";

        public TreePathFinder_UT() { }

        // ------------------------------------------------
        /// <summary>
        ///     Gets or sets the test context which provides
        ///     information about and functionality for the 
        ///     current test run.
        ///</summary>

        public TestContext TestContext { set; get; }

        // ------------------------------------------------

        #region Additional test attributes
#pragma warning disable S125
        // ------------------------------------------------
        // You can use the following additional attributes 
        // as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
#pragma warning restore S125
        #endregion

        // ------------------------------------------------

        [TestMethod]
        [DataRow("CSharp", false, "json.Field 2.Field 2 Object.F2ObjF1.Field 1")]
        [DataRow("Postman", false, "json.Field 2.Field 2 Object.F2ObjF1.Field 1")]
        [DataRow("TreeNode", false, "json.Field 2.Field 2 Object.F2ObjF1.Field 1")]

        [DataRow("TreeNode", true, "json.Field 2.Field 2 Object.F2ObjF1.Field 1")]
        [DataRow("CSharp", true, "json.Field 2.Field 2 Object.F2ObjF1=\"Field 1\"")]
        [DataRow("Postman", true, "pm.expect(json.Field 2.Field 2 Object.F2ObjF1).to.eql(\"Field 1\")")]
        public void GetPath_PathFinder_Returns_The_Expected_Path_String(string pathFinderName, bool terminator, string expected)
        {
            // -------
            // Arrange

            var cr = $"{Environment.NewLine}";
            var crt = $"{Environment.NewLine}\t";

           var sut = PathFinderFactory.GetPathFinder(pathFinderName);

            // ---
            // Log

            Console.WriteLine($"Full Path:{crt}{JSON}{cr}Path Finder:{crt}{pathFinderName}{cr}Terminator:{crt}{terminator}{cr}Expected:{crt}{expected}{cr}");

            // ---
            // Act

            var res = sut.GetPath(JSON, terminator);

            // ---
            // Log

            Console.WriteLine($"Actual:{crt}{res}");

            // ------
            // Assert

            Assert.AreEqual(expected, res);
        }
    }
}