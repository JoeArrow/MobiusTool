﻿#region © 2019 JoeWare.
//
// All rights reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical, or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
#endregion

using System;
using System.Windows.Forms;

using JsonToTreeView;

namespace JSON_Formatter
{
    // ----------------------------------------------------
    /// <summary>
    ///     We are extending the TabControl in order to gain
    ///     full control over some of its inner workings.
    /// </summary>

    public class TabControlEx : TabControl
    {
        private const int MIN_PAGES = 2;
        private event EventHandler TabRenameEvent;
        private event EventHandler TabDeleteEvent;

        public delegate bool PreRemoveTab(int index);
        private PreRemoveTab PreRemoveTabPage { set; get; }

        // ------------------------------------------------

        public TabControlEx()
            : base()
        {
            PreRemoveTabPage = null;
            ContextMenu = BuildTabContextMenu();
        }

        // ------------------------------------------------

        private ContextMenu BuildTabContextMenu()
        {
            var renameTab = new MenuItem("Rename Tab");
            TabRenameEvent = OnRenameTab;
            renameTab.Click += TabRenameEvent;

            var deleteTab = new MenuItem("Delete Tab");
            TabDeleteEvent = OnDeleteTab;
            deleteTab.Click += TabDeleteEvent;

            return new ContextMenu(new MenuItem[] { renameTab, deleteTab });
        }

        // ------------------------------------------------

        private void DeleteTab(int i)
        {
            if(PreRemoveTabPage != null)
            {
                var closeIt = PreRemoveTabPage(i);

                if(!closeIt)
                {
                    return;
                }
            }

            // --------------------------------
            // Don't remove the last query tab.

            if(TabCount > MIN_PAGES)
            {
                TabPages.Remove(TabPages[i]);
            }
        }

        // ------------------------------------------------

        public void AddTab()
        {
            if(SelectedTab != null && SelectedTab.Text.Equals("New Tab"))
            {
                AddTab("", $"{Properties.Settings.Default.DefaultTabText} {TabCount.ToString()}");
            }
        }

        // ------------------------------------------------

        public JTree AddTab(string json, string tabText)
        {
            SelectedTab = Controls[Controls.Count - 1] as TabPage;

            SelectedTab.ImageIndex = 0;
            SelectedTab.Text = tabText;

            Controls.Add(new TabPage() { Text = "New Tab" });

            SelectedTab.Controls.Add(new JTree()
            {
                Size = SelectedTab.ClientSize,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            });

            var retVal = SelectedTab.Controls[0] as JTree;
            retVal.JSON = json;

            return SelectedTab.Controls[0] as JTree;
        }

        // ------------------------------------------------

        protected override void OnMouseClick(MouseEventArgs e)
        {
            var clickPoint = e.Location;
            var text = SelectedTab.Text;

            if(text.Equals("New Tab", StringComparison.CurrentCultureIgnoreCase))
            {
                AddTab();
            }
            else
            {
                // -------------------------------
                // See if the user clicked the 'X'

                for(int i = 0; i < TabCount; i++)
                {
                    var rectangle = GetTabRect(i);

                    rectangle.Width = 16;
                    rectangle.Height = 16;
                    rectangle.Offset(2, 2);

                    if(rectangle.Contains(clickPoint))
                    {
                        DeleteTab(i);
                        break;
                    }
                }
            }
        }

        // ------------------------------------------------

        private void OnRenameTab(object sender, EventArgs e)
        {
            if(SelectedTab != null)
            {
                using(var dlg = new TabRenameDialog(SelectedTab.Text))
                {
                    if(dlg.ShowDialog() == DialogResult.OK)
                    {
                        SelectedTab.Text = dlg.tbNewName.Text;
                    }
                }
            }
        }

        // ------------------------------------------------

        private void OnDeleteTab(object sender, EventArgs e)
        {
            if(SelectedTab != null && TabPages.Count > 2)
            {
                TabPages.Remove(SelectedTab);
            }
        }
    }
}
