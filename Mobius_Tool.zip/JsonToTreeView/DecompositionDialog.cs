﻿#region © 2019 JoeWare.
//
// All rights reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical, or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
#endregion

using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

using JsonToTreeView.Exporters;

namespace JsonToTreeView
{
    public partial class DecompositionDialog : Form
    {
        public IExporter Exporter { get; set; }

        [DllImport("user32.dll", EntryPoint = "FindWindowEx")]
        public static extern IntPtr FindWindowEx(IntPtr hwndParent,
                                                 IntPtr hwndChildAfter,
                                                 string lpszClass,
                                                 string lpszWindow);
        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int uMsg, int wParam, string lParam);

        // ------------------------------------------------

        public DecompositionDialog(string nodeName, string text, IExporter exporter)
        {
            InitializeComponent();

            Exporter = exporter;
            lblNodeName.Text = nodeName;
            tbDecomposition.Text = text;
            btnExport.Tag = tbDecomposition as ScintillaNET.Scintilla;
        }

        // ------------------------------------------------

        private void OnExport(object sender, EventArgs e)
        {
            var textBox = ((Button)sender).Tag as ScintillaNET.Scintilla;

            if(textBox != null)
            {
                Exporter.Export(textBox.Text);
            }
        }

        // ------------------------------------------------

        private void OnOk(object sender, System.EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        // ------------------------------------------------

        private void OnKeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape)
            {
                DialogResult = DialogResult.Cancel;
            }
        }
    }
}
