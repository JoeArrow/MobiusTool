﻿#region © 2019 JoeWare.
//
// All rights reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical, or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
#endregion

using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Configuration;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Collections.Specialized;
using System.Diagnostics.CodeAnalysis;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using ScintillaNET;
using TreePathFinder;
using JsonToTreeView.Exporters;

namespace JsonToTreeView
{
    public partial class JTree : UserControl
    {
        // -----------------------------------------
        // Indicators 0-7 could be in use by a lexer
        // so we'll use indicator 8 to highlight words.

        const int HIGHLIGHT = 8;

        [ExcludeFromCodeCoverage]
        private string FileName { set; get; }
        [ExcludeFromCodeCoverage]
        public IExporter Exporter { set; get; }
        [ExcludeFromCodeCoverage]
        private IPathFinder PathFinder { set; get; } = new NodePathFinder();

        public List<JTree> SplitSyncTargets = new List<JTree>();
        public TreeNode RootNode { get { return tvJSON.Nodes.Count > 0 ? tvJSON.Nodes[0] : null; } }

        internal TreeView tvJSON { get { return trvJSON; } }
        internal Scintilla tbJSON { get { return rtxJSON; } }
        
        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        public string JSON
        {
            set { rtxJSON.Text = value; }
            get { return FixupJSON(rtxJSON.Text, false); }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        public int SplitDistance
        {
            set { sptContainer.SplitterDistance = value; }
            get { return sptContainer.SplitterDistance; }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        public bool LoadExpanded 
        {
            set { cbExpand.Checked = value; }
            get { return cbExpand.Checked; }
        }

        // ------------------------------------------------

        public string[] AvailablePathFinders
        {
            get
            {
                return Enum.GetNames(typeof(eAvailablePathFinders));
            }
        }

        // ------------------------------------------------
        /// <summary>
        ///     Default Constructor
        /// </summary>

        public JTree()
        {
            InitializeComponent();

            JSONStyle();
            LineNumberStyle();
            CodeFoldingStyle();

            searchTool = new SearchTool(this);
            lblNodesFound.Text = string.Empty;
            rtxJSON.ContextMenu = BuildJSONContextMenu();
            Exporter = ExporterFactory.GetExporter("Default");
        }

        // ------------------------------------------------
        /// <summary>
        ///     Overloaded Constructor allowing a command
        ///     line argument or two
        /// </summary>
        /// <param name="json"></param>
        /// <param name="rootName"></param>

        public JTree(string json, string rootName = "json") 
            : this()
        {
            ProcessJSON(json, rootName);
        }

        // ------------------------------------------------
        /// <summary>
        ///     Use the name of a PathFinder to set the object
        /// </summary>
        /// <param name="pathFinder"></param>

        [ExcludeFromCodeCoverage]
        public void SetPathFinder(string pathFinder)
        {
            PathFinder = PathFinderFactory.GetPathFinder(pathFinder);
        }

        // ------------------------------------------------

        public void ProcessJSON(string json, string rootName)
        {
            rtxJSON.Text = json;
            rtxJSON.Tag = false;
            lblNodesFound.Text = string.Empty;

            if(FormatJSON(true))
            {
                try
                {
                    BuildTree(JToken.Parse(rtxJSON.Text), rootName);
                }
                catch(Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        public string SaveJSON(string fileName = "")
        {
            var retVal = string.Empty;

            if(!string.IsNullOrWhiteSpace(fileName))
            {
                fileName = Path.GetFileName(FileName);
            }

            var dlg = new SaveFileDialog()
            {
                FileName = fileName, 
                OverwritePrompt = false,
                Filter = ConfigurationManager.AppSettings["SearchFilter"]
            };

            if(dlg.ShowDialog() == DialogResult.OK)
            {
                retVal = FileName = fileName;
                File.WriteAllText(dlg.FileName, JSON);
            }

            return retVal;
        }

        // ------------------------------------------------

        private Color EnumToColor(eColorConstant colorConst)
        {
            var rgb = (int)colorConst;
            return Color.FromArgb(255, (byte)(rgb >> 16), (byte)(rgb >> 8), (byte)rgb);
        }

        // ------------------------------------------------

        private void BuildTree(JToken root, string rootName)
        {
            trvJSON.BeginUpdate();
            trvJSON.Nodes.Clear();

            Cursor = Cursors.WaitCursor;

            // -------------------------------------
            // Create a root node to anchor the tree

            var node = new TreeNode(rootName);
            var tNode = trvJSON.Nodes[trvJSON.Nodes.Add(node)];
            tNode.ContextMenu = BuildNodeContextMenu(node);

            // ---------------------------------------------
            // AddNode() is recursive, and will traverse the 
            // entire JSON adding nodes.

            AddNode(root, tNode);

            // --------------------------------------------
            // Determine whether or not to expand the nodes

            if(cbExpand.Checked)
            {
                tNode.ExpandAll();
            }
            else
            {
                tNode.Expand();
            }

            trvJSON.EndUpdate();
            Cursor = Cursors.Default;
        }

        // ------------------------------------------------
        /// <summary>
        ///     Recursive Method...
        /// </summary>
        /// <param name="token"></param>
        /// <param name="parentNode"></param>

        private void AddNode(JToken token, TreeNode parentNode)
        {
            if(token != null)
            {
                if(token is JValue)
                {
                    // --------------------------------
                    // With a JValue, we are at a leaf.
                    // No recursion necessary

                    var val = token.ToString();
                    var node = new TreeNode(string.IsNullOrEmpty(val) ? "<Not Set>" : val)
                    {
                        Tag = token as JValue
                    };

                    var childNode = parentNode.Nodes[parentNode.Nodes.Add(node)];

                    // ----------------------
                    // Simple color coding...

                    if(string.IsNullOrEmpty(val))
                    {
                        node.ForeColor = Color.Red;
                        parentNode.ForeColor = Color.Red;
                    }
                    else if(val.StartsWith("{{"))
                    {
                        node.ForeColor = Color.Blue;
                        parentNode.ForeColor = Color.Blue;
                    }

                    childNode.ContextMenu = BuildNodeContextMenu(node);
                }
                else if(token is JObject)
                {
                    // ----------------------------------------
                    // With a JObject, we need to handle all of
                    // the properties...

                    var obj = token as JObject;

                    foreach(var property in obj.Properties())
                    {
                        var node = new TreeNode(property.Name)
                        {
                            Tag = obj
                        };

                        var childNode = parentNode.Nodes[parentNode.Nodes.Add(node)];

                        childNode.ContextMenu = BuildNodeContextMenu(node);

                        // ---------
                        // Recursion

                        AddNode(property.Value, childNode);
                    }
                }
                else if(token is JArray)
                {
                    // -------------------------------------
                    // With a JArray, we need to handle each
                    // of the elements.

                    var array = token as JArray;

                    for(int index = 0; index < array.Count; index++)
                    {
                        var node = new TreeNode($"[{index.ToString()}]")
                        {
                            Tag = array
                        };

                        var childNode = parentNode.Nodes[parentNode.Nodes.Add(node)];

                        childNode.ContextMenu = BuildNodeContextMenu(node);

                        // ---------
                        // Recursion

                        AddNode(array[index], childNode);
                    }
                }
            }
        }

        // ------------------------------------------------
        /// <summary>
        ///     Context Menu for the Treeview
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>

        private ContextMenu BuildNodeContextMenu(TreeNode node)
        {
            var copyNodeValue = new MenuItem("Copy");
            CopyNodeValueEvent = OnCopyNodeValue;
            copyNodeValue.Click += CopyNodeValueEvent;
            copyNodeValue.Tag = node;

            var findNode = new MenuItem("Search");
            SearchEvent = OnSearch;
            findNode.Tag = node;
            findNode.Click += SearchEvent;

            var toggleExpNodeItem = new MenuItem("Toggle Node Expansion");
            ToggleExpansionEvent = OnToggleExpansion;
            toggleExpNodeItem.Tag = node;
            toggleExpNodeItem.Click += ToggleExpansionEvent;

            var copyNodeItem = new MenuItem("Copy Node Path");
            CopyNodePathEvent = OnCopyNodePath;
            copyNodeItem.Click += CopyNodePathEvent;
            copyNodeItem.Tag = node;

            var decomposeNode = new MenuItem("Decompose Node");
            DecomposeNodeEvent = OnDecomposeNode;
            decomposeNode.Tag = node;
            decomposeNode.Click += DecomposeNodeEvent;

            var listTokensNode = new MenuItem("List Tokens");
            ListTokensEvent = OnListTokens;
            listTokensNode.Click += ListTokensEvent;

            return new ContextMenu(new MenuItem[] 
            { 
                copyNodeValue, 
                findNode, 
                toggleExpNodeItem, 
                copyNodeItem, 
                decomposeNode, 
                listTokensNode 
            });
        }

        // ------------------------------------------------
        /// <summary>
        ///     Build the Context Menu for the JSON String
        /// </summary>
        /// <returns></returns>

        private ContextMenu BuildJSONContextMenu()
        {
            var searchFromJSONItem = new MenuItem("Search");
            SearchTreeEvent = OnJSONSearch;
            searchFromJSONItem.Click += SearchTreeEvent;

            var copyItem = new MenuItem("Copy Selected Text");
            CopySelectedEvent = OnCopySelected;
            copyItem.Click += CopySelectedEvent;

            var formatJsonItem = new MenuItem("Toggle JSON Format");
            FormatJSONEvent = OnFormatJSON;
            formatJsonItem.Click += FormatJSONEvent;

            var newJsonItem = new MenuItem("New JSON");
            NewJSONEvent = OnNewJSON;
            newJsonItem.Click += NewJSONEvent;

            var buildItem = new MenuItem("Build The Tree");
            BuildTreeEvent = OnBuildTree;
            buildItem.Click += BuildTreeEvent;

            var replaceValueItem = new MenuItem("Replace Value");
            ReplaceValueEvent = OnReplaceValue;
            replaceValueItem.Click += ReplaceValueEvent;

            var fixupJSONItem = new MenuItem("Fixup JSON");
            FixupJsonEvent = OnFixupJSON;
            fixupJSONItem.Click += FixupJsonEvent;

            var listTokensNode = new MenuItem("List Tokens");
            ListTokensEvent = OnListTokens;
            listTokensNode.Click += ListTokensEvent;

            var retVal = new ContextMenu(new MenuItem[] 
            { 
                searchFromJSONItem, 
                copyItem, 
                formatJsonItem, 
                newJsonItem, 
                buildItem, 
                replaceValueItem, 
                fixupJSONItem, 
                listTokensNode 
            });

            return retVal;
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void CopyNodePath(TreeNode node)
        {
            if(node != null && PathFinder != null)
            {
                // --------------------------------------------------
                // If node.Nodes.Count == 0, then this is a leaf node
                // It has no children...

                Clipboard.SetText(PathFinder.GetPath(node.FullPath, node.Nodes.Count == 0));
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void Search(TreeNode node)
        {
            if(node != null && tvJSON.Nodes.Count > 0)
            {
                using(var dlg = new SearchDialog())
                {
                    if(dlg.ShowDialog() == DialogResult.OK)
                    {
                        Clipboard.SetText(dlg.SearchTerm);
                        lblNodesFound.Text = $"Found: {searchTool.Search(node, dlg.SearchTerm)}";
                    }
                }
            }
        }

        // ------------------------------------------------

        private void CopyText()
        {
            var json = string.Empty;

            // ---------------------------------------
            // If text is selected, use the selection,
            // otherwise use the full text

            if(string.IsNullOrEmpty(rtxJSON.SelectedText))
            {
                json = rtxJSON.Text;
            }
            else
            {
                json = rtxJSON.SelectedText;                
            }

            if(!string.IsNullOrEmpty(json))
            {
                var regEx = new Regex("\"{{\\w+}}\"");
                var matches = regEx.Matches(json);
                var processed = new StringCollection();

                foreach(var cap in matches)
                {
                    if(!processed.Contains(cap.ToString()))
                    {
                        json = Regex.Replace(json, cap.ToString(), cap.ToString().Replace("\"{{", "{{").Replace("}}\"", "}}"));
                        processed.Add(cap.ToString());
                    }
                }

                Clipboard.SetText(json);
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void PasteText()
        {
            trvJSON.Nodes.Clear();
            ProcessJSON(rtxJSON.Text, "json");
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnCopyNodeValue(object sender, EventArgs e)
        {
            var item = sender as MenuItem;
            var node = item.Tag as TreeNode;

            if(node != null)
            {
                Clipboard.SetText(node.Text);
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnCopyNodePath(object sender, EventArgs e)
        {
            var item = sender as MenuItem;
            var node = item.Tag as TreeNode;

            CopyNodePath(node);
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnToggleExpansion(object sender, EventArgs e)
        {
            var item = sender as MenuItem;

            if(item != null)
            {
                Cursor = Cursors.WaitCursor;
                var node = item.Tag as TreeNode;

                if(node != null)
                {
                    if(node.IsExpanded)
                    {
                        node.Collapse();
                    }
                    else
                    {
                        trvJSON.BeginUpdate();
                        node.ExpandAll();
                        trvJSON.EndUpdate();
                    }

                    trvJSON.SelectedNode = node;

                    if(trvJSON.SelectedNode.FirstNode != null)
                    {
                        trvJSON.SelectedNode.EnsureVisible();
                    }
                }

                Cursor = Cursors.Default;
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnJSONSearch(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(rtxJSON.SelectedText))
            {
                lblNodesFound.Text = $"Found: {searchTool.Search(trvJSON.Nodes[0], rtxJSON.SelectedText)}";
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnDecomposeNode(object sender, EventArgs e)
        {
            var output = new StringBuilder();
            var item = sender as MenuItem;

            if(item != null)
            {
                var node = item.Tag as TreeNode;

                if(node != null)
                {
                    if(node.Nodes.Count > 0)
                    {
                        foreach(TreeNode child in node.Nodes)
                        {
                            if(child.Nodes.Count > 0)
                            {
                                var index = 0;

                                foreach(TreeNode target in child.Nodes)
                                {
                                    index++;

                                    if(target.Nodes.Count > 0)
                                    {
                                        if(index < child.Nodes.Count)
                                        {
                                            output.AppendFormat("{0, -45}", target.Nodes[0].Text);
                                        }
                                        else
                                        {
                                            output.AppendFormat("{1}{0}", Environment.NewLine, target.Nodes[0].Text);
                                        }
                                    }
                                    else
                                    {
                                        output.AppendFormat("{0, -45}{1}", child.Text, target.Text);
                                    }
                                }
                            }
                            else
                            {
                                output.AppendFormat("{0, -45}{1}", node.Text, child.Text);
                            }
                        }
                    }
                    else
                    {
                        output.Append(node.Text);
                    }

                    using(var dlg = new DecompositionDialog(node.Text, output.ToString(), Exporter))
                    {
                        dlg.ShowDialog();
                    }
                }
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnSearch(object sender, EventArgs e)
        {
            var item = sender as MenuItem;

            if(item != null)
            {
                Search(item.Tag as TreeNode);
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnListTokens(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            var r = new Regex("{{\\w+}}");

            var matches = r.Matches(rtxJSON.Text);
            var tokens = new List<string>();

            foreach(var match in matches)
            {
                var current = match.ToString().Substring(2, match.ToString().Length - 4);

                if(!tokens.Contains(current))
                {
                    tokens.Add(current);
                }
            }

            tokens.Sort();

            foreach(var token in tokens)
            {
                var delimiter = sb.Length > 0 ? ", " : string.Empty;
                sb.AppendFormat("{0}{1}", delimiter , token);
            }

            var text = sb.Length > 0 ? sb.ToString() : "No Tokens Located...";

            using(var dlg = new DecompositionDialog("Tokens", text + Environment.NewLine, Exporter))
            {
                dlg.Text = "Found Tokens";
                dlg.Size = new Size(1000, 250);

                if(dlg.ShowDialog() == DialogResult.OK)
                {
                    Clipboard.SetText(text);
                }
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnCopySelected(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(rtxJSON.SelectedText))
            {
                Clipboard.SetText(rtxJSON.SelectedText);
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnBuildTree(object sender, EventArgs e)
        {
            ProcessJSON(rtxJSON.Text, "json");
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnFormatJSON(object sender, EventArgs e)
        {
            FormatJSON(!(bool)rtxJSON.Tag);
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnReplaceValue(object sender, EventArgs e)
        {
            var searchTerm = rtxJSON.SelectedText;

            using(var dlg = new ReplaceValueDialog(searchTerm))
            {
                if(dlg.ShowDialog() == DialogResult.OK)
                {
                    // -----------------------------------------
                    // The user MAY have changed the search term

                    searchTerm = dlg.SearchValue;
                    var replacementTerm = dlg.NewValue;

                    rtxJSON.Text = rtxJSON.Text.Replace(searchTerm, replacementTerm);

                    ProcessJSON(rtxJSON.Text, "json");
                }
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnNewJSON(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(rtxJSON.Text))
            {
                trvJSON.Nodes.Clear();
                rtxJSON.Text = "{  }";
            }
            else
            {
                var result = MessageBox.Show("Save Existing JSON?", "Save Your Work", MessageBoxButtons.YesNoCancel);

                switch(result)
                {
                    case DialogResult.Yes:

                        SaveJSON();

                        trvJSON.Nodes.Clear();
                        rtxJSON.Text = "{  }";
                        break;

                    case DialogResult.No:

                        trvJSON.Nodes.Clear();
                        rtxJSON.Text = "{  }";
                        break;

                    default:
                        // Do Nothing !!
                        break;
                }
            }
        }

        // ------------------------------------------------

        private bool FormatJSON(bool pretty)
        {
            var retVal = false;
            rtxJSON.Tag = pretty;
            var token = null as JToken;

            rtxJSON.ScrollWidth = 1;
            rtxJSON.ScrollWidthTracking = true;

            try
            {
                token = JToken.Parse(rtxJSON.Text);
                retVal = true;
            }
            catch(Exception exp)
            {
                retVal = false;
                trvJSON.Nodes.Clear();

                MessageBox.Show(exp.Message);
            }

            if(retVal)
            {
                rtxJSON.Text = token.ToString(pretty ? Formatting.Indented : Formatting.None);
            }

            return retVal;
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void SyncTargets(object sender, SplitterEventArgs e)
        {
            foreach(var target in SplitSyncTargets)
            {
                target.SplitDistance = sptContainer.SplitterDistance;
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        public void OnFixupJSON(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(tbJSON.Text))
            {
                tbJSON.Text = FixupJSON(tbJSON.Text, true);
                OnBuildTree(null, null);
            }
        }

        // ------------------------------------------------
        /// <summary>
        ///     Fixup JSON which may contain Postman Variables
        /// </summary>
        /// <param name="json"></param>

        private string FixupJSON(string json, bool protectVars)
        {
            Regex r;

            if(protectVars)
            {
                r = new Regex("{{\\w+}}");
            }
            else
            {
                r = new Regex("\"{{\\w+}}\"");
            }

            var matches = r.Matches(json);
            var processed = new StringCollection();

            foreach(var match in matches)
            {
                if(!processed.Contains(match.ToString()))
                {
                    json = Regex.Replace(json, match.ToString(), protectVars ? $"\"{match.ToString()}\"" : match.ToString().Replace("\"", ""));
                    processed.Add(match.ToString());
                }
            }

            return json;
        }

        // ------------------------------------------------
        /// <summary>
        ///     F3 for Next
        ///     Shift + F3 for Previous
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        [ExcludeFromCodeCoverage]
        private void OnTreeKeyDown(object sender, KeyEventArgs e)
        {
            if((e.Modifiers == Keys.Control && e.KeyCode == Keys.F3) ||
                (e.Modifiers == Keys.Control && e.KeyCode == Keys.F))
            {
                Search(trvJSON.Nodes[0]);
            }
            else if(e.Modifiers == Keys.None && e.KeyCode == Keys.F3)
            {
                searchTool.Next();
            }
            else if(e.Modifiers == Keys.Shift && e.KeyCode == Keys.F3)
            {
                searchTool.Previous();
            }
            else if(e.Modifiers == Keys.Control && e.KeyCode == Keys.C)
            {
                // ---------------------------------
                // Copy the text of the current node

                Clipboard.SetText(trvJSON.SelectedNode.Text);
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnTreeKeyUp(object sender, KeyEventArgs e)
        {
            if(e.Modifiers == Keys.Control && e.KeyCode == Keys.C)
            {
                // ----
                // Copy 

                var tree = sender as TreeView;
                var node = tree.SelectedNode;

                if(node != null)
                {
                    Clipboard.SetText(node.Text);
                }
            }
            else if(e.Modifiers == Keys.Control && e.KeyCode == Keys.P)
            {
                // -----
                // Paste

                var tree = sender as TreeView;
                var node = tree.SelectedNode;

                if(node != null)
                {
                    CopyNodePath(node);
                }
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnTextKeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyData == Keys.Escape)
            {
                // --------------------------------
                // Remove all uses of our indicator

                rtxJSON.IndicatorCurrent = HIGHLIGHT;
                rtxJSON.IndicatorClearRange(0, rtxJSON.TextLength);
            }
            else if(e.KeyData == (Keys.Control | Keys.C))
            {
                // ----
                // Copy

                CopyText();
            }
            else if(e.KeyData == (Keys.Control | Keys.V))
            {
                // -----
                // Paste

                PasteText();
            }
        }

        // ------------------------------------------------

        [ExcludeFromCodeCoverage]
        private void OnJSONTextChange(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(rtxJSON.Text))
            {
                trvJSON.Nodes.Clear();
            }

            // ---------------------------------------------------------------
            // Did the number of characters in the line number display change?
            // i.e. nnn VS nn, or nnnn VS nn, etc...

            var columnWidth = rtxJSON.Lines.Count.ToString().Length;

            if(columnWidth != maxLineNumberwidth)
            {
                maxLineNumberwidth = columnWidth;

                // ------------------------------------------------------------
                // Calculate the width required to display the last line number
                // and include some padding for good measure.

                const int paddingLeft = 2;

                rtxJSON.Margins[LINENUMBER_MARGIN].Width = rtxJSON.TextWidth(Style.LineNumber, new string('9', maxLineNumberwidth + paddingLeft));
            }
        }
    }
}
